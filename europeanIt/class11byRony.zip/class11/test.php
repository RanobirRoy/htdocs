<?php 
    function outer(){
        // global $a,$b,$c,$d;
        $bangla = 60;
        $english = 70;
        $math = 50;
        function inner($mark){
            if($mark >= 80 and $mark <= 100){
                $gpa = 5.00;
            }elseif($mark >= 70 and $mark <= 79){
                $gpa = 4.00;
            }elseif($mark >= 60 and $mark <= 69){
                $gpa = 3.50;
            }elseif($mark >= 50 and $mark <= 59){
                $gpa = 3.00;
            }elseif($mark >= 40 and $mark <= 49){
                $gpa = 2.00;
            }elseif($mark >= 33 and $mark <= 39){
                $gpa = 1.00;
            }elseif($mark >= 0 and $mark <= 32){
                $gpa = 0.00;
            }else{
                $gpa = 0;
            }
            return $gpa;
        }
        $res = (inner($bangla) + inner($english)) / 2;
        return $res;

    }
    echo outer() . "ha Return";

?>